## Primera practica-CICD

- build
- tests
- coverage
- package
- publish